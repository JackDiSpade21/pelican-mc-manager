<?php

namespace Boy132\MinecraftModrinth\Facades;

use App\Models\Server;
use Boy132\MinecraftModrinth\Enums\ModrinthProjectType;
use Boy132\MinecraftModrinth\Services\MinecraftModrinthService;
use Illuminate\Support\Facades\Facade;

/**
 * @method static ?string getMinecraftVersion(Server $server)
 * @method static ?string getMinecraftLoader(Server $server)
 * @method static ?ModrinthProjectType getModrinthProjectType(Server $server)
 * @method static array{hits: array<int, array<string, mixed>>, total_hits: int} getModrinthProjects(Server $server, int $page = 1, ?string $search = null)
 * @method static array<int, array<string, mixed>> getInstalledProjects(Server $server)
 * @method static array getAvailableUpdates(Server $server)
 * @method static void updateInstalledPlugin(Server $server, string $projectId, array $newVersion)
 * @method static void deleteInstalledPlugin(Server $server, string $projectId)
 * @method static array<int, mixed> getModrinthVersions(string $projectId, Server $server)
 *
 * @see MinecraftModrinthService
 */
class MinecraftModrinth extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return MinecraftModrinthService::class;
    }
}
