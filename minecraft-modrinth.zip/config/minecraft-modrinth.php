<?php

return [
    'latest_minecraft_version' => env('LATEST_MINECRAFT_VERSION', '1.21.11'),
];
